NOMAN EDUCATION — অনলাইন লগইন ও অ্যাডমিন প্যানেল সেটআপ

এই ZIP-এ আছে:
- index.html: ওয়েবসাইটের UI
- app.js: Firebase Authentication ও Firestore যুক্ত করা
- firebase-config.js: Firebase project config বসানোর ফাইল
- firestore.rules: ডেটাবেস নিরাপত্তার নিয়ম
- README_BN.txt: এই নির্দেশনা

গুরুত্বপূর্ণ:
আমি ফাইল তৈরি করেছি; তোমার হয়ে Firebase/GitHub অ্যাকাউন্ট খুলে ওয়েবসাইট প্রকাশ করতে পারি না। প্রথমবার তোমাকে নিচের সেটআপ করতে হবে। Firebase config-এর API key সাধারণত ওয়েব অ্যাপে প্রকাশ্য থাকে; আসল সুরক্ষা Firestore Rules দিয়ে হয়। Firebase service account key বা ব্যক্তিগত পাসওয়ার্ড কখনো ওয়েবসাইটে দেবে না।

ধাপ ১ — Firebase তৈরি
1. https://console.firebase.google.com/ খোলো এবং Google account দিয়ে project তৈরি করো।
2. Project-এর Authentication > Sign-in method থেকে Email/Password চালু করো।
3. Project settings > General > Your apps > Web app তৈরি করো।
4. Firebase যে config দেখাবে, firebase-config.js-এ PASTE_... placeholder-এর জায়গায় বসাও। Project ID/অন্য মান হুবহু কপি করো।
5. Firestore Database তৈরি করো।

ধাপ ২ — Firestore rules
1. Firebase Console > Firestore Database > Rules খোলো।
2. ZIP-এর firestore.rules-এর সম্পূর্ণ লেখা সেখানে বসিয়ে Publish করো।
3. Rules ছাড়া database public করে রেখো না।

ধাপ ৩ — প্রথম অ্যাডমিন বানানো
1. ওয়েবসাইট খুলে Sign up অংশে নিজের ইমেইল দিয়ে একটি account তৈরি করো।
2. Firebase Console > Firestore Database > Data-তে users collection খুঁজে তোমার UID-র document খোলো।
3. ওই document-এর role field-কে "student" থেকে "admin" করো (string value, quotes ছাড়া UI-তে admin)।
4. সাইন আউট করে আবার লগইন করো। এখন Teacher/Admin tab দেখা উচিত।
5. users/{uid} document-এর UID ঠিক account UID-র সঙ্গে মিলতে হবে। Admin role কাউকে দেওয়ার আগে যাচাই করো।

ধাপ ৪ — অনলাইনে প্রকাশ (GitHub Pages)
1. https://github.com/ এ sign in করে noman-education নামে public repository তৈরি করো।
2. index.html, app.js, firebase-config.js ফাইলগুলো repository root-এ upload করো।
3. Repository Settings > Pages > Deploy from a branch > main / root বেছে Save করো।
4. Firebase Console > Authentication > Settings > Authorized domains-এ তোমার GitHub Pages domain যোগ করো (যেমন username.github.io; নিজের প্রকৃত domain বসাবে)।
5. কয়েক মিনিট পরে GitHub Pages-এর দেওয়া URL খোলো। URL repository-এর নাম অনুসারে হতে পারে।
6. যদি GitHub Pages-এর URL-এর নিচে project path থাকে, module file path সাধারণত relative কাজ করবে; সমস্যা হলে console error দেখো।

ব্যবহার
- শিক্ষার্থীরা email/password দিয়ে account খুলে login করবে।
- শুধু Firestore users/{uid}.role == "admin" ব্যবহারকারী অধ্যায়/নোট/সূত্র/MCQ যোগ, সম্পাদনা ও মুছতে পারবে।
- Admin যোগ করা কনটেন্ট Firestore-এ থাকবে এবং লগইন করা শিক্ষার্থীরা অনলাইনে দেখতে পারবে।
- প্রথম সংস্করণে payment, password reset UI, email verification, student profile dashboard, bulk question import বা advanced analytics নেই।

সতর্কতা
- এই প্রকল্পটি starter template; লাইভ করার আগে একজন ওয়েব ডেভেলপার দিয়ে security rules, auth flows, responsive layout ও error handling পরীক্ষা করানো ভালো।
- শিক্ষার্থীদের অপ্রাপ্তবয়স্কদের তথ্য অপ্রয়োজনীয়ভাবে সংগ্রহ কোরো না।
- নোট/প্রশ্ন বর্তমান NCTB বইয়ের সঙ্গে যাচাই করো।
